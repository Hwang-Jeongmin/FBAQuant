from .IngestorInterface import IngestorInterface
from .QuoteModel import QuoteModel
from docx import Document


class IngDOCX(IngestorInterface):
    allowed_extensions = ['docx']

    @classmethod
    def parse(cls, path: str):
        if cls.can_ingest(path) != True:
            raise Exception(
                f'Cannot Ingest Exception{cls.allowed_extensions[0]}')
        docx = Document(path)
        quotes = []
        for par in docx.paragraphs:
            q = par.text.split(' - ')
            quote = QuoteModel(q[0], q[1])
            quotes.append(quote)
        return quotes
