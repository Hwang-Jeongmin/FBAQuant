from .IngestorInterface import IngestorInterface
from .IngTXT import IngTXT
import subprocess
import random
import os


class IngPDF(IngestorInterface):
    allowed_extensions = ['pdf']

    @classmethod
    def parse(cls, path: str):
        if cls.can_ingest(path) != True:
            raise Exception(
                f'Cannot Ingest Exception{cls.allowed_extensions[0]}')

        tmp_file = f'./tmp/{random.randint(0,100)}.txt'
        subprocess.run(['pdftotext', path, tmp_file], shell=True)

        quotes = IngTXT.parse(tmp_file)
        os.remove(tmp_file)
        return quotes
