from .IngestorInterface import IngestorInterface
from .QuoteModel import QuoteModel
import pandas as pd


class IngCSV(IngestorInterface):

    allowed_extensions = ['csv']

    @classmethod
    def parse(cls, path: str):
        if cls.can_ingest(path) != True:
            raise Exception(
                f'Cannot Ingest Exception{cls.allowed_extensions[0]}')

        quotes = []
        df = pd.read_csv(path, header=0)
        for q in df:
            quote = QuoteModel(q['body'], q['author'])
            quotes.append(quote)

        return quotes
