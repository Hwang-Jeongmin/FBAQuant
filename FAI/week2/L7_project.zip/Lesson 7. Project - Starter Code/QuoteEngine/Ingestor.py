from IngestorInterface import IngestorInterface
from .IngCSV import IngCSV
from .IngDOCX import IngDOCX
from .IngTXT import IngTXT
from .IngPDF import IngPDF


class Ingestor(IngestorInterface):

    ingestors = [IngCSV, IngPDF, IngDOCX, IngTXT]

    @classmethod
    def parse(cls, path):
        for Ing in cls.ingestors:
            if Ing.can_ingest(path):
                return Ing.parse(path)
