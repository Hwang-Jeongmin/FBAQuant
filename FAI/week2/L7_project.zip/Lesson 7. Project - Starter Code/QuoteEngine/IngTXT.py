from .IngestorInterface import IngestorInterface
from .QuoteModel import QuoteModel


class IngTXT(IngestorInterface):

    allowed_extensions = ['txt']

    @classmethod
    def parse(cls, path: str):
        if cls.can_ingest(path) != True:
            raise Exception(
                f'Cannot Ingest Exception{cls.allowed_extensions[0]}')

        quotes = []
        with open(path, encoding='utf-8') as f:
            for q in f:
                row = q.split(' - ')
                body = row[0].strip()
                author = row[1].strip()
                quote = QuoteModel(body, author)
                quotes.append(quote)

        return quotes
