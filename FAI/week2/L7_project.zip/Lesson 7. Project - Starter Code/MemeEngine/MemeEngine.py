import PIL


class MemeEngine:

    meme_width = 500
    meme_fill = 'white'
    meme_factor = 18

    def __init__(self, path):
        self.path = path

    def make_meme(self, img, body, author):
        quote = f'{body}, {author}'

        with PIL.Image.open(img) as f:
            w, h = f.size
            scale = self.meme_width / h
